package org.jglr.jchroma.effects;

public enum BreathingType {
    TWO_COLORS,
    RANDOM;

}
